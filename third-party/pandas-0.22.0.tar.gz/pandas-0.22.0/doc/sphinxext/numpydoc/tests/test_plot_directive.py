from __future__ import division, absolute_import, print_function

import numpydoc.plot_directive

# No tests at the moment...
