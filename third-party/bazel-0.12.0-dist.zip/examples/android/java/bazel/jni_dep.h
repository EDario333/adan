#pragma once

#include <jni.h>

jstring NewStringLatin1(JNIEnv *env, const char *str);
